#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
            SIMULATEUR FOMOD v1.0 - SCRIPT PYTHON UNIQUE & AUTONOME
================================================================================
Application de bureau complète avec interface graphique PyQt6 non-bloquante,
moteur de parsing XML FOMOD, simulateur de staging Skyrim Data et extracteur
universel d'archives (.zip, .7z, .rar, .tar, dossiers).

Conception soignée, fidèle au design de l'application web d'origine :
- En-tête supérieur avec indicateurs d'étape et de compatibilité.
- Disposition 3 colonnes : Contrôles & Staging (26%), Sélection des Options (29%),
  Instructions & Aperçu d'image vectoriel dynamique (45%).
- Modales interactives : 'Ouvrir un FOMOD', 'Infos du mod', 'Dossier Data',
  'Staging généré', 'Plein écran'.
- Journalisation rigoureuse via le module natif `logging`.

INSTRUCTIONS DE COMPILATION AUTONOME (PYINSTALLER) :
---------------------------------------------------
1. Prérequis :
   pip install PyQt6 py7zr pyinstaller

2. Compilation binaire autonome (Linux / Windows) :
   pyinstaller --windowed --onefile --name="FOMOD_Simulator" fomod_simulator_standalone.py

3. Compilation application native macOS (.app bundle) :
   pyinstaller --windowed --onefile \
               --name="FOMOD Simulator" \
               --osx-bundle-identifier="com.skyrimtools.fomodsimulator" \
               fomod_simulator_standalone.py

L'exécutable compilé sera directement généré dans le dossier 'dist/'.
================================================================================
"""

import sys
import os
import io
import re
import shutil
import zipfile
import tarfile
import tempfile
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set, Any, Tuple, Callable
from enum import Enum
import xml.etree.ElementTree as ET

# Configuration initiale de logging
logger = logging.getLogger("fomod_simulator")

# ---------------------------------------------------------------------------
# Imports PyQt6 avec validation
# ---------------------------------------------------------------------------
try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QSplitter, QLabel, QPushButton, QScrollArea, QFrame, QTreeWidget,
        QTreeWidgetItem, QProgressBar, QFileDialog, QMessageBox, QDialog,
        QTextEdit, QHeaderView, QTabWidget
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize, QPointF, QRectF
    from PyQt6.QtGui import (
        QPixmap, QPainter, QLinearGradient, QColor, QPen, QBrush, QPolygonF, QFont
    )
except ImportError as err:
    sys.stderr.write(f"ERREUR : Bibliothèque PyQt6 manquante ({err}).\nInstallez-la via : pip install PyQt6\n")
    sys.exit(1)


# ==============================================================================
# 1. STRUCTURES DE DONNÉES DU DOMAINE FOMOD
# ==============================================================================

class GroupType(Enum):
    SelectAny = "SelectAny"
    SelectAll = "SelectAll"
    SelectExactlyOne = "SelectExactlyOne"
    SelectAtMostOne = "SelectAtMostOne"
    SelectAtLeastOne = "SelectAtLeastOne"


@dataclass
class FomodMetadata:
    name: str = "Mod Skyrim"
    author: str = ""
    version: str = "1.0.0"
    website: str = ""
    description: str = ""


@dataclass
class FomodFileItem:
    source: str
    destination: str
    priority: int = 0


@dataclass
class FomodFolderItem:
    source: str
    destination: str
    priority: int = 0


@dataclass
class FileDependency:
    file: str
    state: str  # 'Active' | 'Inactive' | 'Missing'


@dataclass
class FlagDependency:
    flag: str
    value: str


@dataclass
class FomodDependencies:
    operator: str = "And"  # 'And' | 'Or' | 'Not'
    file_dependencies: List[FileDependency] = field(default_factory=list)
    flag_dependencies: List[FlagDependency] = field(default_factory=list)
    nested_dependencies: List['FomodDependencies'] = field(default_factory=list)


@dataclass
class FomodOption:
    id: str
    name: str
    description: str
    image_path: Optional[str] = None
    files: List[FomodFileItem] = field(default_factory=list)
    folders: List[FomodFolderItem] = field(default_factory=list)
    flags: Dict[str, str] = field(default_factory=dict)
    dependencies: Optional[FomodDependencies] = None
    is_default: bool = False


@dataclass
class FomodGroup:
    id: str
    name: str
    type: GroupType
    options: List[FomodOption] = field(default_factory=list)


@dataclass
class FomodStep:
    id: str
    name: str
    groups: List[FomodGroup] = field(default_factory=list)
    visible: bool = True


@dataclass
class VirtualFileEntry:
    path: str
    size: int
    data: Optional[bytes] = None
    extracted_disk_path: Optional[str] = None


@dataclass
class ArchiveIndex:
    files: Dict[str, VirtualFileEntry] = field(default_factory=dict)
    dirs: Dict[str, str] = field(default_factory=dict)
    temp_dir: Optional[str] = None


@dataclass
class StagingItem:
    destination_path: str
    source_entry: VirtualFileEntry
    size: int
    priority: int
    matched_from_option: str


@dataclass
class StagingResult:
    items: List[StagingItem]
    total_size: int
    copied_count: int
    skipped_count: int
    log: List[str]


def format_bytes(sz: int) -> str:
    if sz <= 0:
        return "0 o"
    if sz < 1024:
        return f"{sz} o"
    if sz < 1024 * 1024:
        return f"{sz / 1024:.1f} Ko"
    return f"{sz / (1024 * 1024):.2f} Mo"


# ==============================================================================
# 2. PARSEUR XML FOMOD ROBUSTE & ÉVALUATEUR DE DÉPENDANCES
# ==============================================================================

def norm(path: Optional[str]) -> str:
    if not path:
        return ""
    p = path.replace("\\", "/").strip()
    p = re.sub(r"/+", "/", p)
    p = re.sub(r"^\./", "", p)
    return p.strip("/")


def strip_num_prefix(name: str) -> str:
    base = name.split("/")[-1] if "/" in name else name
    return re.sub(r"^\d+\s*[_-]*\s*", "", base).lower()


def find_file_in_index(index: ArchiveIndex, src: str) -> Optional[VirtualFileEntry]:
    raw_key = norm(src)
    if not raw_key:
        return None
    key = raw_key.lower()

    if key in index.files:
        f = index.files[key]
        if "__macosx" not in f.path.lower():
            return f

    suffix_slash_key = "/" + key
    suffix_cands: List[VirtualFileEntry] = []
    for rel_key, entry in index.files.items():
        if "__macosx" in rel_key:
            continue
        if rel_key.endswith(key) or rel_key.endswith(suffix_slash_key):
            suffix_cands.append(entry)

    if suffix_cands:
        suffix_cands.sort(key=lambda x: len(x.path))
        return suffix_cands[0]

    base = key.split("/")[-1]
    if base:
        base_slash = "/" + base
        base_cands: List[VirtualFileEntry] = []
        for rel_key, entry in index.files.items():
            if "__macosx" in rel_key:
                continue
            if rel_key == base or rel_key.endswith(base_slash):
                base_cands.append(entry)
        if base_cands:
            base_cands.sort(key=lambda x: len(x.path))
            return base_cands[0]

    key_stripped = strip_num_prefix(key)
    for rel_key, entry in index.files.items():
        if "__macosx" in rel_key:
            continue
        rel_stripped = strip_num_prefix(rel_key)
        if rel_stripped == key_stripped or rel_stripped.endswith("/" + key_stripped):
            return entry

    return None


def find_folder_in_index(index: ArchiveIndex, src: str) -> Optional[str]:
    raw_key = norm(src)
    if not raw_key:
        return None
    key = raw_key.lower()

    if key in index.dirs:
        return index.dirs[key]

    suffix_slash_key = "/" + key
    for rel_key, orig in index.dirs.items():
        if rel_key.endswith(key) or rel_key.endswith(suffix_slash_key):
            return orig

    key_stripped = strip_num_prefix(key)
    for rel_key, orig in index.dirs.items():
        rel_stripped = strip_num_prefix(rel_key)
        if rel_stripped == key_stripped or rel_stripped.endswith("/" + key_stripped):
            return orig

    return None


def parse_dependencies_node(dep_el: ET.Element) -> FomodDependencies:
    op = dep_el.attrib.get("operator", "And").capitalize()
    if op not in ("And", "Or", "Not"):
        op = "And"

    file_deps: List[FileDependency] = []
    for f in dep_el.findall("./fileDependency"):
        fn = f.attrib.get("file", "")
        st = f.attrib.get("state", "Active")
        if fn:
            file_deps.append(FileDependency(file=fn, state=st))

    flag_deps: List[FlagDependency] = []
    for fl in dep_el.findall("./flagDependency"):
        flg = fl.attrib.get("flag", "")
        val = fl.attrib.get("value", "")
        if flg:
            flag_deps.append(FlagDependency(flag=flg, value=val))

    nested: List[FomodDependencies] = []
    for sub in dep_el.findall("./dependencies"):
        nested.append(parse_dependencies_node(sub))

    return FomodDependencies(
        operator=op,
        file_dependencies=file_deps,
        flag_dependencies=flag_deps,
        nested_dependencies=nested,
    )


def evaluate_dependencies(
    deps: Optional[FomodDependencies],
    active_flags: Dict[str, str],
    installed_files: Set[str],
) -> bool:
    if not deps:
        return True

    results: List[bool] = []

    for fd in deps.file_dependencies:
        base = fd.file.split("/")[-1].lower()
        is_inst = base in installed_files
        res = (is_inst if fd.state == "Active" else not is_inst)
        results.append(res)

    for fl in deps.flag_dependencies:
        cur_val = active_flags.get(fl.flag, "")
        results.append(cur_val == fl.value)

    for nd in deps.nested_dependencies:
        results.append(evaluate_dependencies(nd, active_flags, installed_files))

    if not results:
        return True

    if deps.operator == "And":
        return all(results)
    elif deps.operator == "Or":
        return any(results)
    elif deps.operator == "Not":
        return not any(results)
    return True


def parse_info_xml(xml_text: str) -> FomodMetadata:
    try:
        cleaned = xml_text.strip().lstrip("\ufeff")
        root = ET.fromstring(cleaned)

        def get_text(tags: List[str]) -> str:
            for tag in tags:
                for el in root.iter():
                    if el.tag.split("}")[-1].lower() == tag.lower() and el.text:
                        return el.text.strip()
            return ""

        name = get_text(["Name", "ModName", "Title"]) or "Mod Skyrim"
        author = get_text(["Author", "Authors"]) or "Inconnu"
        version = get_text(["Version"]) or "1.0.0"
        website = get_text(["Website", "URL", "Homepage", "Link"]) or ""
        desc = get_text(["Description", "Summary", "Details"]) or "(Aucune description disponible)"

        return FomodMetadata(
            name=name,
            author=author,
            version=version,
            website=website,
            description=desc,
        )
    except Exception as e:
        logger.error(f"Erreur parsing info.xml : {e}")
        return FomodMetadata()


def parse_module_config_xml(xml_text: str) -> Tuple[str, List[FomodStep], List[Any]]:
    cleaned = xml_text.strip().lstrip("\ufeff")
    root = ET.fromstring(cleaned)

    mod_name_el = root.find(".//moduleName")
    module_name = mod_name_el.text.strip() if (mod_name_el is not None and mod_name_el.text) else "Mod Skyrim"

    required_files: List[Any] = []
    for req in root.findall(".//requiredInstallFiles/*"):
        tag = req.tag.split("}")[-1].lower()
        s = norm(req.attrib.get("source"))
        d = norm(req.attrib.get("destination"))
        prio = int(req.attrib.get("priority", "0") or "0")
        if not s:
            continue
        if tag == "file":
            required_files.append(FomodFileItem(source=s, destination=d, priority=prio))
        elif tag == "folder":
            required_files.append(FomodFolderItem(source=s, destination=d, priority=prio))

    steps: List[FomodStep] = []
    step_elements = root.findall(".//installSteps/installStep") or root.findall(".//installStep")

    for step_idx, step_el in enumerate(step_elements):
        step_name = step_el.attrib.get("name", "").strip() or f"Étape {step_idx + 1}"
        groups: List[FomodGroup] = []

        group_elements = step_el.findall(".//optionalFileGroups/group") or step_el.findall(".//group")
        for grp_idx, grp_el in enumerate(group_elements):
            group_name = grp_el.attrib.get("name", "").strip() or f"Groupe {grp_idx + 1}"
            raw_type = grp_el.attrib.get("type", "SelectAny")

            try:
                grp_type = GroupType(raw_type)
            except ValueError:
                grp_type = GroupType.SelectAny

            options: List[FomodOption] = []
            plugin_elements = grp_el.findall(".//plugins/plugin") or grp_el.findall(".//plugin")

            for pl_idx, pl_el in enumerate(plugin_elements):
                opt_name = pl_el.attrib.get("name", "").strip()
                if not opt_name:
                    for child in pl_el:
                        if child.tag.split("}")[-1].lower() in ("name", "text") and child.text:
                            opt_name = child.text.strip()
                            break

                desc = ""
                for child in pl_el:
                    if child.tag.split("}")[-1].lower() == "description" and child.text:
                        desc = child.text.strip()
                        break

                image_path: Optional[str] = None
                img_el = pl_el.find(".//image")
                if img_el is not None:
                    p = img_el.attrib.get("path") or img_el.attrib.get("src") or img_el.text
                    image_path = norm(p)

                files: List[FomodFileItem] = []
                for fn in pl_el.findall(".//file"):
                    s = norm(fn.attrib.get("source"))
                    d = norm(fn.attrib.get("destination"))
                    prio = int(fn.attrib.get("priority", "0") or "0")
                    if s:
                        files.append(FomodFileItem(source=s, destination=d, priority=prio))

                folders: List[FomodFolderItem] = []
                for fld in pl_el.findall(".//folder"):
                    s = norm(fld.attrib.get("source"))
                    d = norm(fld.attrib.get("destination"))
                    prio = int(fld.attrib.get("priority", "0") or "0")
                    if s:
                        folders.append(FomodFolderItem(source=s, destination=d, priority=prio))

                if not opt_name:
                    if files:
                        opt_name = files[0].source.split("/")[-1]
                    elif folders:
                        opt_name = folders[0].source.split("/")[-1]
                    else:
                        opt_name = f"Option {pl_idx + 1}"

                flags: Dict[str, str] = {}
                for fl_el in pl_el.findall(".//conditionFlags/flag"):
                    fn = fl_el.attrib.get("name")
                    fv = fl_el.attrib.get("value", "true")
                    if fn:
                        flags[fn] = fv

                deps: Optional[FomodDependencies] = None
                dep_el = pl_el.find(".//typeDescriptor/dependencyType/defaultType/dependencies") or pl_el.find(".//dependencies")
                if dep_el is not None:
                    deps = parse_dependencies_node(dep_el)

                options.append(
                    FomodOption(
                        id=f"step_{step_idx}_grp_{grp_idx}_opt_{pl_idx}",
                        name=opt_name,
                        description=desc,
                        image_path=image_path,
                        files=files,
                        folders=folders,
                        flags=flags,
                        dependencies=deps,
                        is_default=(pl_idx == 0 and grp_type in (GroupType.SelectExactlyOne, GroupType.SelectAtLeastOne)),
                    )
                )

            groups.append(
                FomodGroup(
                    id=f"step_{step_idx}_grp_{grp_idx}",
                    name=group_name,
                    type=grp_type,
                    options=options,
                )
            )

        steps.append(
            FomodStep(
                id=f"step_{step_idx}",
                name=step_name,
                groups=groups,
                visible=True,
            )
        )

    # Déduplication
    unique_steps: List[FomodStep] = []
    seen_sigs: Set[str] = set()
    for s in steps:
        sig = "|".join(
            f"{g.name}:" + ",".join(
                f"{o.name}:" + "+".join(sorted(f.source for f in o.files) + sorted(fo.source for fo in o.folders))
                for o in g.options
            )
            for g in s.groups
        )
        if sig not in seen_sigs:
            seen_sigs.add(sig)
            unique_steps.append(s)

    return module_name, unique_steps, required_files


# ==============================================================================
# 3. EXTRACTION ET STAGING
# ==============================================================================

def resolve_file_destination(dest_rule: str, src_path: str) -> str:
    cleaned_dest = norm(dest_rule)
    cleaned_src = norm(src_path)
    file_name = cleaned_src.split("/")[-1]

    if not cleaned_dest or cleaned_dest == ".":
        return file_name

    ext = ""
    if "." in file_name:
        ext = "." + file_name.split(".")[-1].lower()

    if ext and cleaned_dest.lower().endswith(ext):
        return cleaned_dest

    return f"{cleaned_dest}/{file_name}"


def resolve_folder_destination(dest_rule: str, relative_inside_folder: str) -> str:
    cleaned_dest = norm(dest_rule)
    cleaned_rel = norm(relative_inside_folder)

    if not cleaned_dest or cleaned_dest == ".":
        return cleaned_rel
    return f"{cleaned_dest}/{cleaned_rel}"


def build_staging(
    selected_options: List[FomodOption],
    required_files: List[Any],
    archive_index: ArchiveIndex,
) -> StagingResult:
    dest_map: Dict[str, StagingItem] = {}
    logs: List[str] = []

    def process_item(item: Any, opt_name: str):
        if isinstance(item, FomodFileItem):
            entry = find_file_in_index(archive_index, item.source)
            if entry:
                dest = resolve_file_destination(item.destination, item.source)
                if dest not in dest_map or item.priority >= dest_map[dest].priority:
                    dest_map[dest] = StagingItem(
                        destination_path=dest,
                        source_entry=entry,
                        size=entry.size,
                        priority=item.priority,
                        matched_from_option=opt_name,
                    )
            else:
                logs.append(f"Avertissement : Fichier source non trouvé dans l'archive : '{item.source}'")
        elif isinstance(item, FomodFolderItem):
            folder_orig = find_folder_in_index(archive_index, item.source)
            if folder_orig:
                prefix = folder_orig.lower() + "/"
                for k, entry in archive_index.files.items():
                    if k.startswith(prefix):
                        rel_sub = entry.path[len(folder_orig):].lstrip("/\\")
                        dest = resolve_folder_destination(item.destination, rel_sub)
                        if dest not in dest_map or item.priority >= dest_map[dest].priority:
                            dest_map[dest] = StagingItem(
                                destination_path=dest,
                                source_entry=entry,
                                size=entry.size,
                                priority=item.priority,
                                matched_from_option=opt_name,
                            )
            else:
                logs.append(f"Avertissement : Dossier source non trouvé dans l'archive : '{item.source}'")

    for req in required_files:
        process_item(req, "Requis")

    for opt in selected_options:
        for f in opt.files:
            process_item(f, opt.name)
        for fld in opt.folders:
            process_item(fld, opt.name)

    items = sorted(dest_map.values(), key=lambda x: x.destination_path.lower())
    total_size = sum(x.size for x in items)

    return StagingResult(
        items=items,
        total_size=total_size,
        copied_count=len(items),
        skipped_count=0,
        log=logs,
    )


def export_staging_to_directory(staging: StagingResult, target_dir: str):
    os.makedirs(target_dir, exist_ok=True)
    for item in staging.items:
        dest_full = os.path.join(target_dir, item.destination_path.replace("/", os.sep))
        os.makedirs(os.path.dirname(dest_full), exist_ok=True)

        if item.source_entry.data is not None:
            with open(dest_full, "wb") as f:
                f.write(item.source_entry.data)
        elif item.source_entry.extracted_disk_path and os.path.exists(item.source_entry.extracted_disk_path):
            shutil.copy2(item.source_entry.extracted_disk_path, dest_full)


def export_staging_to_zip(staging: StagingResult, zip_path: str):
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for item in staging.items:
            if item.source_entry.data is not None:
                zf.writestr(item.destination_path, item.source_entry.data)
            elif item.source_entry.extracted_disk_path and os.path.exists(item.source_entry.extracted_disk_path):
                zf.write(item.source_entry.extracted_disk_path, item.destination_path)


# ==============================================================================
# 4. GOUVERNANCE DES IMAGES & APERÇUS VECTORIELS
# ==============================================================================

SAMPLE_PREVIEW_CONFIGS = {
    "fomod/images/curvy.png": {
        "title": "CBBE Curvy Body",
        "subtitle": "Default voluptuous silhouette with smooth curves",
        "bg": "#1e293b",
        "accent": "#38bdf8",
    },
    "fomod/images/slim.png": {
        "title": "CBBE Slim Body",
        "subtitle": "Athletic and slender proportions for female characters",
        "bg": "#1e293b",
        "accent": "#38bdf8",
    },
    "fomod/images/vanilla.png": {
        "title": "CBBE Vanilla Shape",
        "subtitle": "Faithful to original Skyrim proportions",
        "bg": "#1e293b",
        "accent": "#38bdf8",
    },
    "fomod/images/tex4k.png": {
        "title": "4K Ultra Textures",
        "subtitle": "Ultra HD skin pores, specular maps and normal detail",
        "bg": "#312e81",
        "accent": "#a855f7",
    },
    "fomod/images/tex2k.png": {
        "title": "2K High Textures",
        "subtitle": "Balanced fidelity with excellent VRAM performance",
        "bg": "#312e81",
        "accent": "#a855f7",
    },
    "fomod/images/physics.png": {
        "title": "HDT-SMP / CBPC Physics",
        "subtitle": "Real-time soft body physics simulation enabled",
        "bg": "#14532d",
        "accent": "#4ade80",
    },
    "fomod/images/static.png": {
        "title": "Static Body (No Physics)",
        "subtitle": "Maximum FPS, zero performance impact",
        "bg": "#14532d",
        "accent": "#4ade80",
    },
    "fomod/images/underwear.png": {
        "title": "Underwear Version",
        "subtitle": "Includes discrete lore-friendly underwear meshes",
        "bg": "#7c2d12",
        "accent": "#fb923c",
    },
    "fomod/images/nevernude.png": {
        "title": "NeverNude Safe Version",
        "subtitle": "Includes permanent modesty cloth for safe streaming",
        "bg": "#7c2d12",
        "accent": "#fb923c",
    },
    "fomod/images/skyui_patch.png": {
        "title": "SkyUI SE Integration",
        "subtitle": "Custom icons and inventory management tags",
        "bg": "#0f172a",
        "accent": "#fbbf24",
    },
    "fomod/images/racemenu_patch.png": {
        "title": "RaceMenu Overlays",
        "subtitle": "High poly body morph sliders and tattoo overlays",
        "bg": "#0f172a",
        "accent": "#fbbf24",
    },
}


def generate_preview_pixmap(
    title: str,
    subtitle: str,
    bg_color: str = "#1e293b",
    accent_color: str = "#38bdf8",
    width: int = 640,
    height: int = 400,
) -> QPixmap:
    pix = QPixmap(width, height)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    grad = QLinearGradient(0, 0, width, height)
    grad.setColorAt(0.0, QColor(bg_color))
    grad.setColorAt(1.0, QColor("#111111"))
    painter.fillRect(0, 0, width, height, grad)

    grid_pen = QPen(QColor(255, 255, 255, 12), 1)
    painter.setPen(grid_pen)
    step = 40
    for x in range(0, width, step):
        painter.drawLine(x, 0, x, height)
    for y in range(0, height, step):
        painter.drawLine(0, y, width, y)

    cx = width // 2
    cy = 150
    accent = QColor(accent_color)

    circle_pen = QPen(accent, 3)
    painter.setPen(circle_pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawEllipse(cx - 65, cy - 65, 130, 130)

    diamond = QPolygonF([
        QPointF(cx - 38, cy),
        QPointF(cx, cy - 38),
        QPointF(cx + 38, cy),
        QPointF(cx, cy + 38),
    ])
    accent_brush = QColor(accent.red(), accent.green(), accent.blue(), 200)
    painter.setBrush(QBrush(accent_brush))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawPolygon(diamond)

    painter.setPen(QColor("#ffffff"))
    title_font = QFont("-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif", 18, QFont.Weight.Bold)
    painter.setFont(title_font)
    painter.drawText(QRectF(20, 240, width - 40, 34), Qt.AlignmentFlag.AlignCenter, title)

    painter.setPen(QColor("#aaaaaa"))
    sub_font = QFont("-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif", 12)
    painter.setFont(sub_font)
    painter.drawText(QRectF(20, 276, width - 40, 28), Qt.AlignmentFlag.AlignCenter, subtitle)

    badge_rect = QRectF(20, 20, 120, 26)
    painter.setBrush(QColor(0, 0, 0, 180))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawRoundedRect(badge_rect, 4, 4)

    badge_font = QFont("-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif", 9, QFont.Weight.Bold)
    painter.setFont(badge_font)
    painter.setPen(accent)
    painter.drawText(badge_rect, Qt.AlignmentFlag.AlignCenter, "FOMOD PREVIEW")

    # 7. Badge Plein écran (en bas à droite à l'intérieur de l'image comme sur le web)
    fs_rect = QRectF(width - 110, height - 32, 95, 22)
    painter.setBrush(QColor(0, 0, 0, 190))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawRoundedRect(fs_rect, 3, 3)

    fs_font = QFont("-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif", 8, QFont.Weight.Medium)
    painter.setFont(fs_font)
    painter.setPen(QColor("#ffffff"))
    painter.drawText(fs_rect, Qt.AlignmentFlag.AlignCenter, "🔍 Plein écran")

    painter.end()
    return pix


def get_preview_pixmap_for_path(image_path: Optional[str], opt_name: str, opt_desc: str) -> QPixmap:
    if image_path:
        norm_key = image_path.replace("\\", "/").lower()
        for k, cfg in SAMPLE_PREVIEW_CONFIGS.items():
            if norm_key.endswith(k.lower()) or k.lower() in norm_key:
                return generate_preview_pixmap(
                    title=cfg["title"],
                    subtitle=cfg["subtitle"],
                    bg_color=cfg["bg"],
                    accent_color=cfg["accent"],
                )

    sub = (opt_desc.split(".")[0] + ".") if opt_desc else "Option de configuration du mod"
    if len(sub) > 65:
        sub = sub[:62] + "..."
    return generate_preview_pixmap(title=opt_name, subtitle=sub, bg_color="#1e293b", accent_color="#38bdf8")


# ==============================================================================
# 5. MODS DE DÉMONSTRATION INTÉGRÉS
# ==============================================================================

SAMPLE_CBBE_INFO_XML = """<?xml version="1.0" encoding="utf-8"?>
<fomod>
  <Name>Caliente's Beautiful Bodies Enhancer - CBBE - SE</Name>
  <Author>Caliente and Ousnius</Author>
  <Version>2.0.3</Version>
  <Website>https://www.nexusmods.com/skyrimspecialedition/mods/198</Website>
  <Description>Caliente's Beautiful Bodies Enhancer (CBBE) is a complete female body mesh and texture overhaul for The Elder Scrolls V: Skyrim Special Edition.</Description>
</fomod>"""

SAMPLE_CBBE_MODULE_CONFIG_XML = """<?xml version="1.0" encoding="utf-8"?>
<moduleConfiguration xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://qconsulting.ca/fo3/ModConfig5.0.xsd">
  <moduleName>Caliente's Beautiful Bodies Enhancer - CBBE - SE</moduleName>
  <requiredInstallFiles>
    <folder source="00 Core" destination="." priority="0"/>
  </requiredInstallFiles>
  <installSteps order="Explicit">
    <installStep name="Silhouette &amp; Version du corps">
      <optionalFileGroups order="Explicit">
        <group name="Type de corps principal" type="SelectExactlyOne">
          <plugins order="Explicit">
            <plugin name="CBBE Curvy (Recommandé)">
              <description>The standard voluptuous body shape. Best for users looking for feminine curves and full compatibility with existing armor conversions. Recommended for most players.</description>
              <image path="fomod/images/curvy.png"/>
              <files>
                <folder source="01 Curvy/meshes" destination="meshes" priority="1"/>
              </files>
            </plugin>
            <plugin name="CBBE Slim">
              <description>A more slender, athletic physique with reduced proportions. Maintains smooth topology and accurate rigging.</description>
              <image path="fomod/images/slim.png"/>
              <files>
                <folder source="01 Slim/meshes" destination="meshes" priority="1"/>
              </files>
            </plugin>
            <plugin name="CBBE Vanilla Shape">
              <description>Body proportions matched closely to original Bethesda Skyrim models while retaining the high vertex count and seamless seams of CBBE.</description>
              <image path="fomod/images/vanilla.png"/>
              <files>
                <folder source="01 Vanilla/meshes" destination="meshes" priority="1"/>
              </files>
            </plugin>
          </plugins>
        </group>
      </optionalFileGroups>
    </installStep>

    <installStep name="Résolution des Textures">
      <optionalFileGroups order="Explicit">
        <group name="Pack de textures de peau" type="SelectExactlyOne">
          <plugins order="Explicit">
            <plugin name="Textures 4K Ultra HD (Haute Qualité)">
              <description>Ultra-high definition diffuse, subsurface scattering, normal maps and specular maps (4096x4096). Recommended for GPUs with 6GB+ VRAM.</description>
              <image path="fomod/images/tex4k.png"/>
              <files>
                <folder source="02 Textures 4K/textures" destination="textures" priority="2"/>
              </files>
            </plugin>
            <plugin name="Textures 2K Haute Performance">
              <description>High quality 2048x2048 textures. Sharp details with minimal performance impact and reduced memory footprint.</description>
              <image path="fomod/images/tex2k.png"/>
              <files>
                <folder source="02 Textures 2K/textures" destination="textures" priority="2"/>
              </files>
            </plugin>
          </plugins>
        </group>
      </optionalFileGroups>
    </installStep>

    <installStep name="Moteur Physique &amp; Animation">
      <optionalFileGroups order="Explicit">
        <group name="Prise en charge de la physique" type="SelectExactlyOne">
          <plugins order="Explicit">
            <plugin name="Physique HDT-SMP / CBPC">
              <description>Enables dynamic physics weighting for breast, butt, and belly motion in real-time. Requires HDT-SMP or CBPC plugins.</description>
              <image path="fomod/images/physics.png"/>
              <files>
                <folder source="03 Physics/meshes" destination="meshes" priority="3"/>
                <file source="03 Physics/CBBE_Physics.esp" destination="CBBE_Physics.esp" priority="3"/>
              </files>
            </plugin>
            <plugin name="Corps Statique (Sans Physique)">
              <description>Standard static weighting without extra performance overhead. Recommended for lower end systems.</description>
              <image path="fomod/images/static.png"/>
              <files>
                <folder source="03 Static/meshes" destination="meshes" priority="3"/>
              </files>
            </plugin>
          </plugins>
        </group>
      </optionalFileGroups>
    </installStep>

    <installStep name="Tenues &amp; Modestie">
      <optionalFileGroups order="Explicit">
        <group name="Version des sous-vêtements" type="SelectExactlyOne">
          <plugins order="Explicit">
            <plugin name="Sous-vêtements (Underwear)">
              <description>Replaces default underwear with custom fitted textures and models for CBBE.</description>
              <image path="fomod/images/underwear.png"/>
              <files>
                <folder source="04 Underwear/meshes" destination="meshes" priority="4"/>
                <folder source="04 Underwear/textures" destination="textures" priority="4"/>
              </files>
            </plugin>
            <plugin name="NeverNude (Sécurisé pour Streaming)">
              <description>Includes permanent modesty cloth for safe livestreaming and public gameplay.</description>
              <image path="fomod/images/nevernude.png"/>
              <files>
                <folder source="04 NeverNude/meshes" destination="meshes" priority="4"/>
                <folder source="04 NeverNude/textures" destination="textures" priority="4"/>
              </files>
            </plugin>
          </plugins>
        </group>
      </optionalFileGroups>
    </installStep>

    <installStep name="Patches de Compatibilité">
      <optionalFileGroups order="Explicit">
        <group name="Modules additionnels" type="SelectAny">
          <plugins order="Explicit">
            <plugin name="Patch d'intégration SkyUI SE">
              <description>Adds inventory icons and category filters tailored for body items. Automatically preselected when SkyUI_SE.esp is detected in Data.</description>
              <image path="fomod/images/skyui_patch.png"/>
              <files>
                <file source="05 Patches/CBBE_SkyUI_Addon.esp" destination="CBBE_SkyUI_Addon.esp" priority="5"/>
              </files>
              <dependencies operator="And">
                <fileDependency file="SkyUI_SE.esp" state="Active"/>
              </dependencies>
            </plugin>
            <plugin name="Support des Sliders RaceMenu (skee64)">
              <description>Installs body morph sliders, overlay textures and bodypaint slots into RaceMenu character generation menu.</description>
              <image path="fomod/images/racemenu_patch.png"/>
              <files>
                <folder source="05 RaceMenu/SKSE" destination="SKSE" priority="5"/>
                <file source="05 RaceMenu/CBBE_RaceMenu_Morphs.esp" destination="CBBE_RaceMenu_Morphs.esp" priority="5"/>
              </files>
              <dependencies operator="And">
                <fileDependency file="skee64.dll" state="Active"/>
              </dependencies>
            </plugin>
          </plugins>
        </group>
      </optionalFileGroups>
    </installStep>
  </installSteps>
</moduleConfiguration>"""


def get_demo_mod() -> Tuple[ArchiveIndex, str, str]:
    files: Dict[str, VirtualFileEntry] = {}
    dirs: Dict[str, str] = {}

    info_bytes = SAMPLE_CBBE_INFO_XML.encode("utf-8")
    files["fomod/info.xml"] = VirtualFileEntry(path="fomod/info.xml", size=len(info_bytes), data=info_bytes)
    dirs["fomod"] = "fomod"

    cfg_bytes = SAMPLE_CBBE_MODULE_CONFIG_XML.encode("utf-8")
    files["fomod/moduleconfig.xml"] = VirtualFileEntry(path="fomod/ModuleConfig.xml", size=len(cfg_bytes), data=cfg_bytes)

    dummy_files = [
        "00 Core/meshes/actors/character/character assets/femalehead.nif",
        "00 Core/textures/actors/character/female/femalehead.dds",
        "01 Curvy/meshes/actors/character/character assets/femalebody_0.nif",
        "01 Curvy/meshes/actors/character/character assets/femalebody_1.nif",
        "01 Slim/meshes/actors/character/character assets/femalebody_0.nif",
        "01 Slim/meshes/actors/character/character assets/femalebody_1.nif",
        "01 Vanilla/meshes/actors/character/character assets/femalebody_0.nif",
        "01 Vanilla/meshes/actors/character/character assets/femalebody_1.nif",
        "02 Textures 4K/textures/actors/character/female/femalebody_4k.dds",
        "02 Textures 4K/textures/actors/character/female/femalebody_msn.dds",
        "02 Textures 2K/textures/actors/character/female/femalebody_2k.dds",
        "02 Textures 2K/textures/actors/character/female/femalebody_msn.dds",
        "03 Physics/meshes/actors/character/character assets/femalebody_physics.nif",
        "03 Physics/CBBE_Physics.esp",
        "03 Static/meshes/actors/character/character assets/femalebody_static.nif",
        "04 Underwear/meshes/actors/character/character assets/femaleunderwear.nif",
        "04 Underwear/textures/actors/character/female/underwear.dds",
        "04 NeverNude/meshes/actors/character/character assets/nevernude.nif",
        "04 NeverNude/textures/actors/character/female/nevernude.dds",
        "05 Patches/CBBE_SkyUI_Addon.esp",
        "05 RaceMenu/SKSE/Plugins/CharGen/Overlays.ini",
        "05 RaceMenu/CBBE_RaceMenu_Morphs.esp",
    ]

    for fpath in dummy_files:
        k = fpath.lower()
        sz = 14200 if fpath.endswith(".esp") else 854000
        files[k] = VirtualFileEntry(path=fpath, size=sz, data=b"DUMMY_DATA")

        parts = fpath.split("/")
        cur = ""
        for i in range(len(parts) - 1):
            cur = f"{cur}/{parts[i]}" if cur else parts[i]
            dirs[cur.lower()] = cur

    return ArchiveIndex(files=files, dirs=dirs), SAMPLE_CBBE_MODULE_CONFIG_XML, SAMPLE_CBBE_INFO_XML


# ==============================================================================
# 6. WORKERS QTHREAD NON-BLOQUANTS
# ==============================================================================

class StagingWorker(QThread):
    finished = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, selected_options: List[FomodOption], required_files: List[Any], archive_index: ArchiveIndex, parent=None):
        super().__init__(parent)
        self.selected_options = selected_options
        self.required_files = required_files
        self.archive_index = archive_index

    def run(self):
        try:
            res = build_staging(self.selected_options, self.required_files, self.archive_index)
            self.finished.emit(res)
        except Exception as e:
            logger.exception("Erreur staging worker")
            self.error.emit(str(e))


class ArchiveExtractWorker(QThread):
    finished = pyqtSignal(object, str, str)
    error = pyqtSignal(str)

    def __init__(self, target_path: str, parent=None):
        super().__init__(parent)
        self.target_path = target_path

    def run(self):
        try:
            files: Dict[str, VirtualFileEntry] = {}
            dirs: Dict[str, str] = {}
            tmp = tempfile.mkdtemp(prefix="fomod_extracted_")

            if os.path.isdir(self.target_path):
                for root, _, fnames in os.walk(self.target_path):
                    for fn in fnames:
                        fp = os.path.join(root, fn)
                        rel = os.path.relpath(fp, self.target_path).replace("\\", "/")
                        sz = os.path.getsize(fp)
                        files[rel.lower()] = VirtualFileEntry(path=rel, size=sz, extracted_disk_path=fp)
                        parts = rel.split("/")
                        cur = ""
                        for i in range(len(parts) - 1):
                            cur = f"{cur}/{parts[i]}" if cur else parts[i]
                            dirs[cur.lower()] = cur
            elif zipfile.is_zipfile(self.target_path):
                with zipfile.ZipFile(self.target_path, "r") as zf:
                    zf.extractall(tmp)
                    for root, _, fnames in os.walk(tmp):
                        for fn in fnames:
                            fp = os.path.join(root, fn)
                            rel = os.path.relpath(fp, tmp).replace("\\", "/")
                            sz = os.path.getsize(fp)
                            files[rel.lower()] = VirtualFileEntry(path=rel, size=sz, extracted_disk_path=fp)
                            parts = rel.split("/")
                            cur = ""
                            for i in range(len(parts) - 1):
                                cur = f"{cur}/{parts[i]}" if cur else parts[i]
                                dirs[cur.lower()] = cur

            index = ArchiveIndex(files=files, dirs=dirs, temp_dir=tmp)

            info_xml = ""
            for k, entry in index.files.items():
                if k.endswith("fomod/info.xml"):
                    if entry.extracted_disk_path:
                        with open(entry.extracted_disk_path, "r", encoding="utf-8", errors="ignore") as f:
                            info_xml = f.read()
                    break

            cfg_xml = ""
            for k, entry in index.files.items():
                if k.endswith("fomod/moduleconfig.xml"):
                    if entry.extracted_disk_path:
                        with open(entry.extracted_disk_path, "r", encoding="utf-8", errors="ignore") as f:
                            cfg_xml = f.read()
                    break

            self.finished.emit(index, cfg_xml, info_xml)
        except Exception as e:
            logger.exception("Erreur extraction archive")
            self.error.emit(str(e))


# ==============================================================================
# 7. COMPOSANTS GRAPHIQUES & MODALES
# ==============================================================================

class IndicatorWidget(QWidget):
    """Indicateur visuel (Radio rond ou Checkbox carré) identique au web."""

    def __init__(self, is_single: bool, is_checked: bool, parent=None):
        super().__init__(parent)
        self.is_single = is_single
        self.is_checked = is_checked
        self.setFixedSize(18, 18)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(1, 1, -1, -1)

        if self.is_single:
            if self.is_checked:
                painter.setPen(QPen(QColor("#0ea5e9"), 1.5))
                painter.setBrush(QBrush(QColor("#0ea5e9")))
                painter.drawEllipse(rect)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QBrush(QColor("#ffffff")))
                painter.drawEllipse(rect.center(), 3, 3)
            else:
                painter.setPen(QPen(QColor("#555555"), 1.5))
                painter.setBrush(QBrush(QColor("#222222")))
                painter.drawEllipse(rect)
        else:
            if self.is_checked:
                painter.setPen(QPen(QColor("#0ea5e9"), 1.5))
                painter.setBrush(QBrush(QColor("#0ea5e9")))
                painter.drawRoundedRect(rect, 3, 3)
                painter.setPen(QPen(QColor("#ffffff"), 1.8))
                painter.drawLine(rect.left() + 4, rect.top() + 8, rect.left() + 7, rect.bottom() - 4)
                painter.drawLine(rect.left() + 7, rect.bottom() - 4, rect.right() - 4, rect.top() + 5)
            else:
                painter.setPen(QPen(QColor("#555555"), 1.5))
                painter.setBrush(QBrush(QColor("#222222")))
                painter.drawRoundedRect(rect, 3, 3)

        painter.end()


class OptionRowWidget(QFrame):
    """Ligne d'option FOMOD interactive."""

    def __init__(self, option: FomodOption, is_single: bool, is_selected: bool, matches_dep: bool, on_select, on_hover, parent=None):
        super().__init__(parent)
        self.option = option
        self.is_single = is_single
        self.is_selected = is_selected
        self.on_select = on_select
        self.on_hover = on_hover
        self.setObjectName("OptionRow")
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(10)

        self.indicator = IndicatorWidget(is_single, is_selected)
        layout.addWidget(self.indicator, alignment=Qt.AlignmentFlag.AlignVCenter)

        self.label = QLabel(option.name)
        layout.addWidget(self.label, 1)

        if matches_dep:
            badge = QLabel("Auto")
            badge.setStyleSheet(
                "background-color: rgba(14, 165, 233, 0.2); border: 1px solid rgba(14, 165, 233, 0.3); color: #38bdf8; font-size: 9px; font-weight: bold; padding: 1px 4px; border-radius: 3px;"
            )
            layout.addWidget(badge)

        self._update_style()

    def _update_style(self, hovered: bool = False):
        bg = "#2a2a2a" if self.is_selected else ("#282828" if hovered else "transparent")
        text_color = "#ffffff" if (self.is_selected or hovered) else "#cccccc"
        weight = "bold" if self.is_selected else "normal"
        self.setStyleSheet(f"QFrame#OptionRow {{ background-color: {bg}; border-radius: 4px; }}")
        self.label.setStyleSheet(f"background: transparent; border: none; font-size: 12px; font-weight: {weight}; color: {text_color};")

    def enterEvent(self, event):
        self._update_style(hovered=True)
        self.on_hover(self.option)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._update_style(hovered=False)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.on_select(self.option)
        super().mousePressEvent(event)


class OpenModModal(QDialog):
    """Modale 'Ouvrir un FOMOD'."""

    def __init__(self, parent=None, on_open_archive=None, on_open_folder=None, on_load_sample=None):
        super().__init__(parent)
        self.setWindowTitle("Ouvrir un FOMOD")
        self.setMinimumSize(520, 480)
        self.resize(560, 520)
        self.setStyleSheet("QDialog { background-color: #1e1e1e; color: #ffffff; border: 1px solid #333333; border-radius: 6px; }")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        hdr_row = QHBoxLayout()
        title_lbl = QLabel("📦  Ouvrir un FOMOD")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")
        hdr_row.addWidget(title_lbl)
        hdr_row.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(28, 28)
        close_btn.setStyleSheet("QPushButton { background-color: transparent; border: none; color: #888888; font-size: 16px; } QPushButton:hover { color: #ffffff; }")
        close_btn.clicked.connect(self.reject)
        hdr_row.addWidget(close_btn)
        layout.addLayout(hdr_row)

        div1 = QFrame()
        div1.setFrameShape(QFrame.Shape.HLine)
        div1.setStyleSheet("background-color: #333333; max-height: 1px;")
        layout.addWidget(div1)

        sec1_lbl = QLabel("DEPUIS VOTRE ORDINATEUR")
        sec1_lbl.setStyleSheet("font-size: 11px; font-weight: bold; color: #888888;")
        layout.addWidget(sec1_lbl)

        btn_archive = QPushButton()
        btn_archive.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_archive.setStyleSheet("QPushButton { background-color: #262626; border: 1px solid #383838; border-radius: 4px; padding: 12px; text-align: left; } QPushButton:hover { background-color: #303030; border-color: #fbbf24; }")
        btn_arch_layout = QVBoxLayout(btn_archive)
        btn_arch_layout.setContentsMargins(4, 2, 4, 2)
        btn_arch_layout.setSpacing(4)

        arch_row = QHBoxLayout()
        arch_title = QLabel("📦 Parcourir une archive (.ZIP, .RAR, .7Z)")
        arch_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #fbbf24;")
        arch_badge = QLabel("Support complet")
        arch_badge.setStyleSheet("font-size: 10px; color: #4ade80; background-color: rgba(74, 222, 128, 0.1); border: 1px solid rgba(74, 222, 128, 0.3); border-radius: 3px; padding: 2px 6px;")
        arch_row.addWidget(arch_title)
        arch_row.addStretch()
        arch_row.addWidget(arch_badge)
        btn_arch_layout.addLayout(arch_row)

        arch_desc = QLabel("Sélectionnez directement votre archive téléchargée (.zip, .rar ou .7z).")
        arch_desc.setStyleSheet("font-size: 11px; color: #aaaaaa;")
        btn_arch_layout.addWidget(arch_desc)
        btn_archive.clicked.connect(lambda: (self.accept(), on_open_archive and on_open_archive()))
        layout.addWidget(btn_archive)

        btn_folder = QPushButton()
        btn_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_folder.setStyleSheet("QPushButton { background-color: #262626; border: 1px solid #383838; border-radius: 4px; padding: 12px; text-align: left; } QPushButton:hover { background-color: #303030; border-color: #0ea5e9; }")
        btn_fold_layout = QVBoxLayout(btn_folder)
        btn_fold_layout.setContentsMargins(4, 2, 4, 2)
        btn_fold_layout.setSpacing(4)

        fold_row = QHBoxLayout()
        fold_title = QLabel("📂 Parcourir un dossier décompressé")
        fold_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #38bdf8;")
        fold_badge = QLabel("Dossier local")
        fold_badge.setStyleSheet("font-size: 10px; color: #888888; padding: 2px 4px;")
        fold_row.addWidget(fold_title)
        fold_row.addStretch()
        fold_row.addWidget(fold_badge)
        btn_fold_layout.addLayout(fold_row)

        fold_desc = QLabel("Sélectionnez directement votre dossier local contenant les fichiers du mod.")
        fold_desc.setStyleSheet("font-size: 11px; color: #aaaaaa;")
        btn_fold_layout.addWidget(fold_desc)
        btn_folder.clicked.connect(lambda: (self.accept(), on_open_folder and on_open_folder()))
        layout.addWidget(btn_folder)

        layout.addSpacing(6)
        sec2_lbl = QLabel("MODS DE DÉMONSTRATION RÉALISTES INTÉGRÉS")
        sec2_lbl.setStyleSheet("font-size: 11px; font-weight: bold; color: #888888;")
        layout.addWidget(sec2_lbl)

        btn_cbbe = QPushButton()
        btn_cbbe.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_cbbe.setStyleSheet("QPushButton { background-color: #222222; border: 1px solid #333333; border-radius: 4px; padding: 10px 12px; text-align: left; } QPushButton:hover { background-color: #2a2a2a; border-color: #4ade80; }")
        cbbe_layout = QHBoxLayout(btn_cbbe)
        cbbe_layout.setContentsMargins(4, 2, 4, 2)
        cbbe_title = QLabel("CBBE - Caliente's Beautiful Bodies Enhancer SE")
        cbbe_title.setStyleSheet("font-size: 12px; font-weight: 600; color: #ffffff;")
        cbbe_tag = QLabel("Charger →")
        cbbe_tag.setStyleSheet("font-size: 11px; color: #4ade80; font-weight: bold;")
        cbbe_layout.addWidget(cbbe_title)
        cbbe_layout.addStretch()
        cbbe_layout.addWidget(cbbe_tag)
        btn_cbbe.clicked.connect(lambda: (self.accept(), on_load_sample and on_load_sample("cbbe")))
        layout.addWidget(btn_cbbe)

        layout.addStretch()


class StagingResultModal(QDialog):
    """Modale de résultat de staging."""

    def __init__(self, result: StagingResult, staging_dir_path: str = "Bureau (Desktop)", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Staging généré avec succès")
        self.setMinimumSize(780, 560)
        self.resize(860, 620)
        self.setStyleSheet("QDialog { background-color: #1e1e1e; color: #ffffff; border: 1px solid #333333; border-radius: 6px; }")
        self.result = result
        self.staging_dir_path = staging_dir_path

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        top_row = QHBoxLayout()
        icon_lbl = QLabel("✓")
        icon_lbl.setStyleSheet("font-size: 20px; font-weight: bold; color: #0ea5e9;")
        title_lbl = QLabel("Staging généré avec succès !")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")
        top_row.addWidget(icon_lbl)
        top_row.addWidget(title_lbl)
        top_row.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(28, 28)
        close_btn.setStyleSheet("QPushButton { background-color: transparent; border: none; color: #888888; font-size: 16px; } QPushButton:hover { color: #ffffff; }")
        close_btn.clicked.connect(self.accept)
        top_row.addWidget(close_btn)
        layout.addLayout(top_row)

        sub_info = QLabel(
            f"<b>{result.copied_count}</b> fichiers préparés &bull; "
            f"Taille totale : <b>{format_bytes(result.total_size)}</b> &bull; "
            f"Destination : <span style='color:#38bdf8;'>{staging_dir_path}</span>"
        )
        sub_info.setStyleSheet("font-size: 12px; color: #aaaaaa;")
        layout.addWidget(sub_info)

        tabs = QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #333333; background-color: #161616; border-radius: 4px; }
            QTabBar::tab { background-color: #262626; color: #aaaaaa; padding: 6px 16px; margin-right: 4px; }
            QTabBar::tab:selected { background-color: #161616; color: #0ea5e9; font-weight: bold; }
        """)

        tab_files = QWidget()
        tab_layout = QVBoxLayout(tab_files)
        tab_layout.setContentsMargins(8, 8, 8, 8)

        tree = QTreeWidget()
        tree.setHeaderLabels(["Destination dans Data", "Taille", "Source Option"])
        tree.setStyleSheet("QTreeWidget { background-color: #161616; border: none; color: #f1f1f1; font-family: monospace; font-size: 12px; } QHeaderView::section { background-color: #222222; color: #888888; padding: 4px 8px; border: 1px solid #333333; font-weight: bold; font-size: 11px; }")
        tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)

        for item in result.items:
            leaf = QTreeWidgetItem([item.destination_path, format_bytes(item.size), item.matched_from_option])
            tree.addTopLevelItem(leaf)

        tab_layout.addWidget(tree)
        tabs.addTab(tab_files, "Fichiers installés")

        tab_log = QWidget()
        log_layout = QVBoxLayout(tab_log)
        log_edit = QTextEdit()
        log_edit.setReadOnly(True)
        log_edit.setStyleSheet("background-color: #161616; border: none; color: #aaaaaa; font-family: monospace; font-size: 11px;")
        log_edit.setText("\n".join(result.log) if result.log else "Aucun avertissement. Installation propre.")
        log_layout.addWidget(log_edit)
        tabs.addTab(tab_log, "Journal de staging")

        layout.addWidget(tabs)

        btn_bar = QHBoxLayout()
        export_zip_btn = QPushButton("📦 Exporter en archive ZIP")
        export_zip_btn.setStyleSheet("QPushButton { background-color: #333333; border: 1px solid #444444; color: #ffffff; font-size: 12px; font-weight: 600; padding: 8px 16px; border-radius: 4px; } QPushButton:hover { background-color: #404040; }")
        export_zip_btn.clicked.connect(self._export_zip)
        btn_bar.addWidget(export_zip_btn)

        btn_bar.addStretch()

        close_dialog_btn = QPushButton("Fermer")
        close_dialog_btn.setStyleSheet("QPushButton { background-color: #0ea5e9; color: #ffffff; font-weight: bold; font-size: 12px; padding: 8px 20px; border-radius: 4px; border: none; } QPushButton:hover { background-color: #0284c7; }")
        close_dialog_btn.clicked.connect(self.accept)
        btn_bar.addWidget(close_dialog_btn)

        layout.addLayout(btn_bar)

    def _export_zip(self):
        path, _ = QFileDialog.getSaveFileName(self, "Enregistrer le mod ZIP", "Staging_Skyrim_Mod.zip", "Archive ZIP (*.zip)")
        if path:
            export_staging_to_zip(self.result, path)


class ModInfoDialog(QDialog):
    """Informations sur le mod (info.xml)."""

    def __init__(self, metadata: FomodMetadata, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Informations - {metadata.name}")
        self.setMinimumSize(520, 380)
        self.resize(560, 420)
        self.setStyleSheet("QDialog { background-color: #1e1e1e; color: #ffffff; border: 1px solid #333333; border-radius: 6px; }")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        title_lbl = QLabel(metadata.name)
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        title_lbl.setWordWrap(True)
        layout.addWidget(title_lbl)

        author_row = QHBoxLayout()
        auth_lbl = QLabel(f"<b>Auteur :</b> {metadata.author or 'Inconnu'}")
        auth_lbl.setStyleSheet("color: #aaaaaa; font-size: 12px;")
        author_row.addWidget(auth_lbl)

        ver_lbl = QLabel(f"<b>Version :</b> {metadata.version or '1.0'}")
        ver_lbl.setStyleSheet("color: #38bdf8; font-size: 12px;")
        author_row.addWidget(ver_lbl)
        author_row.addStretch()
        layout.addLayout(author_row)

        desc_box = QTextEdit()
        desc_box.setReadOnly(True)
        desc_box.setStyleSheet("background-color: #161616; border: 1px solid #2d2d2d; color: #e4e4e7; font-size: 12px; padding: 8px; border-radius: 4px;")
        desc_box.setText(metadata.description or "(Aucune description disponible)")
        layout.addWidget(desc_box)

        close_btn = QPushButton("Fermer")
        close_btn.setStyleSheet("QPushButton { background-color: #333333; color: #ffffff; padding: 6px 18px; border-radius: 4px; border: 1px solid #444444; } QPushButton:hover { background-color: #444444; }")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)


class DataDirModal(QDialog):
    """Choisir le dossier Data de Skyrim."""

    def __init__(self, current_data_path: Optional[str], installed_plugins: Set[str], on_apply, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Dossier Data de Skyrim")
        self.setMinimumSize(540, 400)
        self.resize(580, 420)
        self.setStyleSheet("QDialog { background-color: #1e1e1e; color: #ffffff; border: 1px solid #333333; border-radius: 6px; }")

        self.data_path = current_data_path or ""
        self.plugins = set(installed_plugins)
        self.on_apply = on_apply

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        title_lbl = QLabel("📂  Dossier Data de Skyrim (Détection automatique)")
        title_lbl.setStyleSheet("font-size: 15px; font-weight: bold; color: #ffffff;")
        layout.addWidget(title_lbl)

        path_box = QFrame()
        path_box.setStyleSheet("background-color: #161616; border: 1px solid #2d2d2d; border-radius: 4px; padding: 8px;")
        path_layout = QVBoxLayout(path_box)
        path_layout.setContentsMargins(4, 2, 4, 2)
        self.path_val_lbl = QLabel(self.data_path or "(Aucun dossier sélectionné)")
        self.path_val_lbl.setStyleSheet("font-size: 12px; font-family: monospace; color: #38bdf8;")
        path_layout.addWidget(self.path_val_lbl)
        layout.addWidget(path_box)

        btn_row = QHBoxLayout()
        pick_btn = QPushButton("📁 Parcourir le disque...")
        pick_btn.setStyleSheet("QPushButton { background-color: #333333; border: 1px solid #444444; color: #ffffff; font-size: 12px; padding: 6px 14px; border-radius: 4px; } QPushButton:hover { background-color: #444444; }")
        pick_btn.clicked.connect(self._pick_folder)
        btn_row.addWidget(pick_btn)

        sim_btn = QPushButton("⚡ Simuler plugins Skyrim (CBPC, SkyUI, skee64)")
        sim_btn.setStyleSheet("QPushButton { background-color: #0284c7; border: 1px solid #38bdf8; color: #ffffff; font-size: 12px; font-weight: bold; padding: 6px 14px; border-radius: 4px; } QPushButton:hover { background-color: #0ea5e9; }")
        sim_btn.clicked.connect(self._sim_plugins)
        btn_row.addWidget(sim_btn)
        layout.addLayout(btn_row)

        self.plugins_text = QTextEdit()
        self.plugins_text.setReadOnly(True)
        self.plugins_text.setStyleSheet("background-color: #161616; border: 1px solid #2d2d2d; color: #cccccc; font-family: monospace; font-size: 11px; padding: 6px;")
        self._update_display()
        layout.addWidget(self.plugins_text)

        close_btn = QPushButton("Valider & Fermer")
        close_btn.setStyleSheet("QPushButton { background-color: #0ea5e9; color: #ffffff; font-weight: bold; font-size: 12px; padding: 8px 20px; border-radius: 4px; border: none; } QPushButton:hover { background-color: #0284c7; }")
        close_btn.clicked.connect(self._apply)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)

    def _pick_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier Skyrim Data")
        if folder:
            self.data_path = folder
            self.path_val_lbl.setText(folder)
            found = set()
            for root, _, files in os.walk(folder):
                for f in files:
                    if f.lower().endswith((".esp", ".esm", ".esl", ".dll")):
                        found.add(f.lower())
            self.plugins = found
            self._update_display()

    def _sim_plugins(self):
        self.data_path = "C:/Program Files/Steam/steamapps/common/Skyrim Special Edition/Data"
        self.path_val_lbl.setText(self.data_path)
        self.plugins = {"skyrim.esm", "skyui_se.esp", "cbpc.dll", "skee64.dll", "hdtSMP64.dll".lower()}
        self._update_display()

    def _update_display(self):
        self.plugins_text.setText("\n".join(sorted(self.plugins)) if self.plugins else "(Aucun plugin détecté)")

    def _apply(self):
        if self.on_apply:
            self.on_apply(self.data_path, self.plugins)
        self.accept()


class ImagePreviewModal(QDialog):
    """Boîte de dialogue plein écran pour l'image."""

    def __init__(self, pixmap: QPixmap, title: str = "Aperçu FOMOD", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(700, 500)
        self.resize(800, 560)
        self.setStyleSheet("QDialog { background-color: #121212; border: 1px solid #333333; }")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        lbl = QLabel()
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setPixmap(pixmap.scaled(780, 500, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        layout.addWidget(lbl)

        close_btn = QPushButton("Fermer")
        close_btn.setStyleSheet("QPushButton { background-color: #333333; color: #ffffff; padding: 6px 16px; border-radius: 4px; border: 1px solid #444444; } QPushButton:hover { background-color: #444444; }")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)


# ==============================================================================
# 8. FENÊTRE PRINCIPALE DU SIMULATEUR FOMOD
# ==============================================================================

DARK_THEME_QSS = """
QMainWindow {
    background-color: #1e1e1e;
    color: #dddddd;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
}

QDialog {
    background-color: #1e1e1e;
    color: #ffffff;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
    border: 1px solid #333333;
    border-radius: 6px;
}

QFrame#HeaderBar {
    background-color: #262626;
    border: 1px solid #333333;
    border-radius: 4px;
    min-height: 40px;
    max-height: 40px;
}

QFrame#LeftColFrame {
    background-color: #262626;
    border: 1px solid #333333;
    border-radius: 4px;
}

QFrame#CenterColFrame {
    background-color: #222222;
    border: 1px solid #333333;
    border-radius: 4px;
}

QFrame#RightColFrame {
    background-color: #222222;
    border: 1px solid #333333;
    border-radius: 4px;
}

QSplitter::handle {
    background-color: #1e1e1e;
}
QSplitter::handle:horizontal {
    width: 8px;
}
QSplitter::handle:horizontal:hover {
    background-color: rgba(14, 165, 233, 0.4);
}

QPushButton {
    background-color: #333333;
    color: #ffffff;
    border: 1px solid #444444;
    border-radius: 4px;
    padding: 6px 14px;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #404040;
    border-color: #555555;
}
QPushButton:pressed {
    background-color: #262626;
}
QPushButton:disabled {
    background-color: #2a2a2a;
    color: #555555;
    border-color: #333333;
}

QScrollArea {
    background-color: transparent;
    border: none;
}

QScrollBar:vertical {
    background-color: #1a1a1a;
    width: 8px;
    margin: 0px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background-color: #333333;
    min-height: 20px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background-color: #555555;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar:horizontal {
    background-color: #1a1a1a;
    height: 8px;
    margin: 0px;
    border-radius: 4px;
}
QScrollBar::handle:horizontal {
    background-color: #333333;
    min-width: 20px;
    border-radius: 4px;
}
QScrollBar::handle:horizontal:hover {
    background-color: #555555;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0px;
}

QTreeWidget, QListWidget {
    background-color: #181818;
    color: #e0e0e0;
    border: 1px solid #2e2e2e;
    border-radius: 4px;
    padding: 4px;
}
QTreeWidget::item, QListWidget::item {
    padding: 4px 6px;
    border-radius: 3px;
}
QTreeWidget::item:hover, QListWidget::item:hover {
    background-color: #282828;
}
QTreeWidget::item:selected, QListWidget::item:selected {
    background-color: #0369a1;
    color: #ffffff;
}
QHeaderView::section {
    background-color: #242424;
    color: #aaaaaa;
    padding: 4px 8px;
    border: none;
    border-bottom: 1px solid #333333;
    font-size: 11px;
    font-weight: bold;
}

QLineEdit, QTextEdit, QPlainTextEdit {
    background-color: #1a1a1a;
    color: #ffffff;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
    padding: 6px 10px;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border-color: #0ea5e9;
}
"""


class MainWindow(QMainWindow):
    """Fenêtre principale du Simulateur FOMOD en PyQt6."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Caliente's Beautiful Bodies Enhancer - CBBE - SE - Simulateur FOMOD")
        self.resize(1340, 840)
        self.setMinimumSize(1000, 680)

        self.archive_index: ArchiveIndex = ArchiveIndex()
        self.metadata: FomodMetadata = FomodMetadata(
            name="Caliente's Beautiful Bodies Enhancer - CBBE - SE",
            author="Caliente and Ousnius",
            version="2.0.3",
            website="https://www.nexusmods.com/skyrimspecialedition/mods/198",
            description="",
        )
        self.steps: List[FomodStep] = []
        self.required_files = []
        self.current_step_idx = 0
        self.selected_option_ids: Set[str] = set()
        self.active_flags: Dict[str, str] = {}
        self.active_preview_option: Optional[FomodOption] = None
        self.current_staging_result: Optional[StagingResult] = None
        self.installed_basenames: Set[str] = set()

        self.data_dir_path: Optional[str] = None
        self.staging_dir_path: str = "Bureau (Desktop)"

        self.staging_tree = QTreeWidget()
        self.staging_tree.setHeaderLabels(["Destination dans Data", "Taille", "Source Option"])

        self._extract_worker: Optional[ArchiveExtractWorker] = None
        self._staging_worker: Optional[StagingWorker] = None

        self._init_ui()
        self.load_demo_mod()

    def _init_ui(self):
        central = QWidget()
        central.setObjectName("RootWidget")
        central.setStyleSheet("QWidget#RootWidget { background-color: #1e1e1e; }")
        self.setCentralWidget(central)
        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(12, 12, 12, 12)
        root_layout.setSpacing(8)

        # 1. En-tête
        root_layout.addWidget(self._create_header())

        # 2. Séparateur 3 colonnes (Splitter)
        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.addWidget(self._create_left_column())
        self.splitter.addWidget(self._create_center_column())
        self.splitter.addWidget(self._create_right_column())
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setSizes([260, 310, 430])
        root_layout.addWidget(self.splitter, 1)

    def _create_header(self) -> QWidget:
        header = QFrame()
        header.setObjectName("HeaderBar")
        header.setFixedHeight(40)
        header.setStyleSheet("background-color: #262626; border: 1px solid #333333; border-radius: 4px;")
        layout = QHBoxLayout(header)
        layout.setContentsMargins(12, 0, 12, 0)
        layout.setSpacing(10)

        left_box = QHBoxLayout()
        left_box.setSpacing(8)
        bolt_icon = QLabel("⚡")
        bolt_icon.setStyleSheet("color: #fbbf24; font-size: 14px; font-weight: bold;")
        left_box.addWidget(bolt_icon)

        self.title_label = QLabel(self.metadata.name)
        self.title_label.setStyleSheet("color: #ffffff; font-weight: bold; font-size: 13px;")
        left_box.addWidget(self.title_label)
        layout.addLayout(left_box)

        layout.addStretch()

        right_box = QHBoxLayout()
        right_box.setSpacing(10)

        self.step_counter_label = QLabel("Étape 1 / 5")
        self.step_counter_label.setStyleSheet("color: #888888; font-family: monospace; font-size: 11px;")
        right_box.addWidget(self.step_counter_label)

        div2 = QLabel("|")
        div2.setStyleSheet("color: #555555;")
        right_box.addWidget(div2)

        self.env_badge_label = QLabel("Skyrim SE/AE")
        self.env_badge_label.setStyleSheet("color: #aaaaaa; font-size: 11px;")
        right_box.addWidget(self.env_badge_label)

        layout.addLayout(right_box)
        return header

    def _create_left_column(self) -> QWidget:
        col = QFrame()
        col.setObjectName("LeftColFrame")
        col.setStyleSheet("background-color: #262626; border: 1px solid #333333; border-radius: 4px;")
        layout = QVBoxLayout(col)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        top_box = QVBoxLayout()
        top_box.setSpacing(8)

        self.btn_open_fomod = QPushButton("📦  Ouvrir un FOMOD")
        self.btn_open_fomod.setFixedHeight(56)
        self.btn_open_fomod.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_open_fomod.setStyleSheet("""
            QPushButton {
                background-color: #fbbf24;
                color: #1a1a1a;
                font-weight: bold;
                font-size: 14px;
                border-radius: 4px;
                border: none;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #f59e0b;
            }
            QPushButton:pressed {
                background-color: #d97706;
            }
        """)
        self.btn_open_fomod.clicked.connect(self._open_open_mod_modal)
        top_box.addWidget(self.btn_open_fomod)

        self.btn_mod_info = QPushButton("ℹ️  Infos du mod")
        self.btn_mod_info.setFixedHeight(34)
        self.btn_mod_info.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_mod_info.setStyleSheet("""
            QPushButton {
                background-color: #444444;
                color: #ffffff;
                font-size: 12px;
                font-weight: 500;
                border-radius: 4px;
                border: none;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #505050;
            }
        """)
        self.btn_mod_info.clicked.connect(self._show_mod_info_dialog)
        top_box.addWidget(self.btn_mod_info)

        self.btn_choose_data = QPushButton("📂  Choisir le dossier Data")
        self.btn_choose_data.setFixedHeight(34)
        self.btn_choose_data.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_choose_data.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: #ffffff;
                font-size: 12px;
                font-weight: 500;
                border: 1px solid #444444;
                border-radius: 4px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #404040;
            }
        """)
        self.btn_choose_data.clicked.connect(self._open_data_dir_modal)
        top_box.addWidget(self.btn_choose_data)

        self.data_status_label = QLabel()
        self.data_status_label.setTextFormat(Qt.TextFormat.RichText)
        self.data_status_label.setText(
            '<span style="font-weight:600; color:#dddddd;">Data :</span> <span style="font-style:italic; color:#bbbbbb;">(non défini)</span><br/><span style="color:#888888; font-size:10px;">(Cliquez pour simuler Skyrim)</span>'
        )
        self.data_status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.data_status_label.setStyleSheet("font-size: 11px; line-height: 1.3;")
        top_box.addWidget(self.data_status_label)

        layout.addLayout(top_box)
        layout.addStretch()

        bottom_box = QVBoxLayout()
        bottom_box.setSpacing(8)

        div = QFrame()
        div.setFrameShape(QFrame.Shape.HLine)
        div.setStyleSheet("background-color: #333333; max-height: 1px;")
        bottom_box.addWidget(div)

        self.btn_choose_dest = QPushButton("📁  Choisir le dossier")
        self.btn_choose_dest.setFixedHeight(34)
        self.btn_choose_dest.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_choose_dest.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: #ffffff;
                font-size: 12px;
                font-weight: 600;
                border: 1px solid #444444;
                border-radius: 4px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #404040;
            }
        """)
        self.btn_choose_dest.clicked.connect(self._pick_staging_destination)
        bottom_box.addWidget(self.btn_choose_dest)

        dest_card = QFrame()
        dest_card.setStyleSheet("background-color: #1a1a1a; border: 1px solid #2a2a2a; border-radius: 4px; padding: 6px;")
        dest_layout = QVBoxLayout(dest_card)
        dest_layout.setContentsMargins(4, 2, 4, 2)
        dest_layout.setSpacing(2)

        dest_hdr = QLabel("Destination :")
        dest_hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dest_hdr.setStyleSheet("color: #888888; font-size: 10px;")
        dest_layout.addWidget(dest_hdr)

        self.dest_path_label = QLabel(self.staging_dir_path)
        self.dest_path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.dest_path_label.setStyleSheet("color: #38bdf8; font-size: 11px; font-weight: 500; font-family: monospace;")
        dest_layout.addWidget(self.dest_path_label)
        bottom_box.addWidget(dest_card)

        self.btn_generate_staging = QPushButton("GÉNÉRER LE STAGING")
        self.btn_generate_staging.setFixedHeight(40)
        self.btn_generate_staging.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_generate_staging.setStyleSheet("""
            QPushButton {
                background-color: #0ea5e9;
                color: #ffffff;
                font-weight: bold;
                font-size: 12px;
                letter-spacing: 0.5px;
                border-radius: 4px;
                border: none;
                padding: 8px 12px;
            }
            QPushButton:hover {
                background-color: #0284c7;
            }
            QPushButton:pressed {
                background-color: #0369a1;
            }
        """)
        self.btn_generate_staging.clicked.connect(self._on_generate_staging)
        bottom_box.addWidget(self.btn_generate_staging)

        layout.addLayout(bottom_box)
        return col

    def _create_center_column(self) -> QWidget:
        col = QFrame()
        col.setObjectName("CenterColFrame")
        col.setStyleSheet("background-color: #222222; border: 1px solid #333333; border-radius: 4px;")
        layout = QVBoxLayout(col)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        step_header = QFrame()
        step_header.setObjectName("StepHeader")
        step_header.setStyleSheet("QFrame#StepHeader { border-bottom: 1px solid #333333; background-color: transparent; }")
        step_header_layout = QHBoxLayout(step_header)
        step_header_layout.setContentsMargins(14, 12, 14, 12)

        self.step_title_label = QLabel("Silhouette & Version du corps")
        self.step_title_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #ffffff;")
        step_header_layout.addWidget(self.step_title_label)

        step_header_layout.addStretch()

        self.step_index_label = QLabel("1 / 5")
        self.step_index_label.setStyleSheet("color: #888888; font-family: monospace; font-size: 11px;")
        step_header_layout.addWidget(self.step_index_label)
        layout.addWidget(step_header)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("QScrollArea { background-color: transparent; border: none; }")
        self.groups_widget = QWidget()
        self.groups_layout = QVBoxLayout(self.groups_widget)
        self.groups_layout.setContentsMargins(12, 12, 12, 12)
        self.groups_layout.setSpacing(12)
        self.scroll_area.setWidget(self.groups_widget)
        layout.addWidget(self.scroll_area, 1)

        nav_bar = QFrame()
        nav_bar.setObjectName("NavBar")
        nav_bar.setStyleSheet("QFrame#NavBar { border-top: 1px solid #333333; background-color: #222222; }")
        nav_layout = QHBoxLayout(nav_bar)
        nav_layout.setContentsMargins(12, 12, 12, 12)
        nav_layout.setSpacing(10)

        self.btn_prev = QPushButton("RETOUR")
        self.btn_prev.setFixedHeight(38)
        self.btn_prev.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_prev.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: #ffffff;
                font-weight: bold;
                font-size: 12px;
                letter-spacing: 0.5px;
                border-radius: 4px;
                border: 1px solid #444444;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #404040;
            }
            QPushButton:disabled {
                background-color: #222222;
                color: #555555;
                border: 1px solid #333333;
            }
        """)
        self.btn_prev.clicked.connect(self._prev_step)
        nav_layout.addWidget(self.btn_prev)

        self.btn_next = QPushButton("CONTINUER")
        self.btn_next.setFixedHeight(38)
        self.btn_next.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_next.setStyleSheet("""
            QPushButton {
                background-color: #0ea5e9;
                color: #ffffff;
                font-weight: bold;
                font-size: 12px;
                letter-spacing: 0.5px;
                border-radius: 4px;
                border: none;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #0284c7;
            }
            QPushButton:pressed {
                background-color: #0369a1;
            }
            QPushButton:disabled {
                background-color: rgba(14, 165, 233, 0.4);
                color: rgba(255, 255, 255, 0.4);
                border: none;
            }
        """)
        self.btn_next.clicked.connect(self._next_step)
        nav_layout.addWidget(self.btn_next, 1)

        layout.addWidget(nav_bar)
        return col

    def _create_right_column(self) -> QWidget:
        col = QFrame()
        col.setObjectName("RightColFrame")
        col.setStyleSheet("background-color: #222222; border: 1px solid #333333; border-radius: 4px;")
        layout = QVBoxLayout(col)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        sec_title = QLabel("📖  INSTRUCTIONS & DESCRIPTION")
        sec_title.setStyleSheet("font-size: 11px; font-weight: bold; color: #888888; letter-spacing: 0.5px;")
        layout.addWidget(sec_title)

        desc_card = QFrame()
        desc_card.setStyleSheet("background-color: rgba(26, 26, 26, 0.6); border: 1px solid #2e2e2e; border-radius: 4px; padding: 14px;")
        desc_layout = QVBoxLayout(desc_card)
        desc_layout.setContentsMargins(4, 4, 4, 4)

        self.preview_desc_label = QLabel("Description de l'option...")
        self.preview_desc_label.setWordWrap(True)
        self.preview_desc_label.setStyleSheet("color: #f1f1f1; font-size: 14px; line-height: 1.5;")
        desc_layout.addWidget(self.preview_desc_label)
        layout.addWidget(desc_card)

        preview_img_frame = QFrame()
        preview_img_frame.setObjectName("PreviewCard")
        preview_img_frame.setStyleSheet("""
            QFrame#PreviewCard {
                background-color: #1a1a1a;
                border: 1px solid #333333;
                border-radius: 4px;
            }
            QFrame#PreviewCard:hover {
                border: 1px solid #0ea5e9;
            }
        """)
        img_layout = QVBoxLayout(preview_img_frame)
        img_layout.setContentsMargins(4, 4, 4, 4)
        img_layout.setSpacing(0)

        self.preview_image_label = QLabel()
        self.preview_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_image_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.preview_image_label.mousePressEvent = lambda e: self._open_image_preview_modal()
        preview_img_frame.mousePressEvent = lambda e: self._open_image_preview_modal()
        img_layout.addWidget(self.preview_image_label)

        layout.addWidget(preview_img_frame)
        layout.addStretch()
        return col

    def load_demo_mod(self, mod_id: str = "cbbe"):
        try:
            index, cfg_xml, info_xml = get_demo_mod()
            self.archive_index = index
            self.metadata = parse_info_xml(info_xml)
            mod_name, steps, req_files = parse_module_config_xml(cfg_xml)

            if mod_name:
                self.metadata.name = mod_name
            self.title_label.setText(self.metadata.name)
            self.steps = steps
            self.required_files = req_files
            self.current_step_idx = 0
            self.selected_option_ids.clear()
            self.active_flags.clear()

            for step in self.steps:
                for grp in step.groups:
                    chosen = None
                    for opt in grp.options:
                        if opt.is_default:
                            chosen = opt
                            break
                    if not chosen and grp.options:
                        chosen = grp.options[0]
                    if chosen:
                        self.selected_option_ids.add(chosen.id)
                        for k, v in chosen.flags.items():
                            self.active_flags[k] = v

            self._render_current_step()
            self._trigger_background_staging()
        except Exception as e:
            logger.error(f"Erreur chargement mod démo : {e}")

    def _render_current_step(self):
        total_steps = len(self.steps)
        step_num = self.current_step_idx + 1 if total_steps > 0 else 0
        step_name = self.steps[self.current_step_idx].name if (self.steps and self.current_step_idx < len(self.steps)) else ""

        self.step_counter_label.setText(
            f"Étape {step_num} / {total_steps} : {step_name}" if step_name else f"Étape {step_num} / {total_steps}"
        )
        self.step_index_label.setText(f"{step_num} / {total_steps}")

        self.btn_prev.setEnabled(self.current_step_idx > 0)
        self.btn_next.setEnabled(self.current_step_idx < total_steps - 1)

        while self.groups_layout.count() > 0:
            item = self.groups_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if not self.steps or self.current_step_idx >= len(self.steps):
            self.step_title_label.setText("Aucune étape disponible")
            return

        current_step = self.steps[self.current_step_idx]
        self.step_title_label.setText(current_step.name)

        first_option = None

        for grp in current_step.groups:
            grp_box = QFrame()
            grp_box.setObjectName("GroupCard")
            grp_box.setStyleSheet("QFrame#GroupCard { background-color: #222222; border: 1px solid #333333; border-radius: 4px; }")
            grp_layout = QVBoxLayout(grp_box)
            grp_layout.setContentsMargins(12, 12, 12, 12)
            grp_layout.setSpacing(6)

            grp_hdr = QHBoxLayout()
            grp_name = QLabel(grp.name)
            grp_name.setStyleSheet("font-size: 12px; font-weight: bold; color: #dddddd;")
            grp_hdr.addWidget(grp_name)
            grp_hdr.addStretch()

            is_single = grp.type in (GroupType.SelectExactlyOne, GroupType.SelectAtMostOne)
            grp_type_lbl = QLabel("Choix unique" if is_single else "Choix multiple")
            grp_type_lbl.setStyleSheet("font-size: 10px; color: #888888;")
            grp_hdr.addWidget(grp_type_lbl)
            grp_layout.addLayout(grp_hdr)

            div = QFrame()
            div.setFrameShape(QFrame.Shape.HLine)
            div.setStyleSheet("background-color: #2d2d2d; max-height: 1px; border: none; margin-bottom: 4px;")
            grp_layout.addWidget(div)

            for opt in grp.options:
                if first_option is None:
                    first_option = opt

                is_sel = opt.id in self.selected_option_ids
                matches_dep = False
                if opt.dependencies and opt.dependencies.file_dependencies:
                    matches_dep = any(
                        fd.file.split("/")[-1].lower() in self.installed_basenames
                        for fd in opt.dependencies.file_dependencies
                    )

                row = OptionRowWidget(
                    option=opt,
                    is_single=is_single,
                    is_selected=is_sel,
                    matches_dep=matches_dep,
                    on_select=lambda o=opt, g=grp: self._on_select_option(o, g),
                    on_hover=self._on_hover_option,
                )
                grp_layout.addWidget(row)

            self.groups_layout.addWidget(grp_box)

        self.groups_layout.addStretch()

        if first_option:
            self._on_hover_option(first_option)

    def _on_hover_option(self, option: FomodOption):
        self.active_preview_option = option
        self.preview_desc_label.setText(option.description or "(Aucune description disponible pour cette option)")

        pixmap = get_preview_pixmap_for_path(option.image_path, option.name, option.description)
        scaled = pixmap.scaled(
            540, 338,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.preview_image_label.setPixmap(scaled)

    def _on_select_option(self, option: FomodOption, group: FomodGroup):
        is_single = group.type in (GroupType.SelectExactlyOne, GroupType.SelectAtMostOne)

        if is_single:
            for opt in group.options:
                self.selected_option_ids.discard(opt.id)
            self.selected_option_ids.add(option.id)
        else:
            if option.id in self.selected_option_ids:
                self.selected_option_ids.remove(option.id)
            else:
                self.selected_option_ids.add(option.id)

        self.active_flags.clear()
        for step in self.steps:
            for grp in step.groups:
                for opt in grp.options:
                    if opt.id in self.selected_option_ids:
                        for k, v in opt.flags.items():
                            self.active_flags[k] = v

        self._render_current_step()
        self._on_hover_option(option)
        self._trigger_background_staging()

    def _next_step(self):
        if self.current_step_idx < len(self.steps) - 1:
            self.current_step_idx += 1
            self._render_current_step()

    def _prev_step(self):
        if self.current_step_idx > 0:
            self.current_step_idx -= 1
            self._render_current_step()

    def _trigger_background_staging(self):
        selected_opts = []
        for step in self.steps:
            for grp in step.groups:
                for opt in grp.options:
                    if opt.id in self.selected_option_ids:
                        selected_opts.append(opt)

        if self._staging_worker and self._staging_worker.isRunning():
            self._staging_worker.terminate()
            self._staging_worker.wait()

        self._staging_worker = StagingWorker(
            selected_options=selected_opts,
            required_files=self.required_files,
            archive_index=self.archive_index,
        )
        self._staging_worker.finished.connect(self._on_staging_finished)
        self._staging_worker.start()

    def _on_staging_finished(self, result: StagingResult):
        self.current_staging_result = result
        self.staging_tree.clear()
        for item in result.items:
            leaf = QTreeWidgetItem([item.destination_path, format_bytes(item.size), item.matched_from_option])
            self.staging_tree.addTopLevelItem(leaf)

    def _on_generate_staging(self):
        selected_opts = []
        for step in self.steps:
            for grp in step.groups:
                for opt in grp.options:
                    if opt.id in self.selected_option_ids:
                        selected_opts.append(opt)

        res = build_staging(selected_opts, self.required_files, self.archive_index)
        self.current_staging_result = res

        if os.path.exists(self.staging_dir_path):
            try:
                export_staging_to_directory(res, self.staging_dir_path)
            except Exception as e:
                logger.error(f"Erreur copie directe staging : {e}")

        modal = StagingResultModal(res, self.staging_dir_path, self)
        modal.exec()

    def _open_open_mod_modal(self):
        modal = OpenModModal(
            parent=self,
            on_open_archive=self._pick_archive_file,
            on_open_folder=self._pick_folder_mod,
            on_load_sample=self.load_demo_mod,
        )
        modal.exec()

    def _show_mod_info_dialog(self):
        dialog = ModInfoDialog(self.metadata, self)
        dialog.exec()

    def _open_data_dir_modal(self):
        modal = DataDirModal(
            current_data_path=self.data_dir_path,
            installed_plugins=self.installed_basenames,
            on_apply=self._apply_data_dir,
            parent=self,
        )
        modal.exec()

    def _apply_data_dir(self, path: str, plugins: Set[str]):
        self.data_dir_path = path
        self.installed_basenames = plugins
        if path:
            self.data_status_label.setText(
                f'<span style="font-weight:600; color:#dddddd;">Data :</span> <span style="color:#bbbbbb;">{os.path.basename(path)}</span><br/><span style="color:#38bdf8; font-size:10px;">({len(plugins)} fichiers détectés)</span>'
            )
        else:
            self.data_status_label.setText(
                '<span style="font-weight:600; color:#dddddd;">Data :</span> <span style="font-style:italic; color:#bbbbbb;">(non défini)</span><br/><span style="color:#888888; font-size:10px;">(Cliquez pour simuler Skyrim)</span>'
            )
        self._render_current_step()

    def _pick_staging_destination(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier de destination du Staging")
        if folder:
            self.staging_dir_path = folder
            self.dest_path_label.setText(folder)

    def _pick_archive_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Sélectionner l'archive du mod FOMOD", "", "Archives Mod (*.zip *.7z *.rar *.tar *.gz);;Tous les fichiers (*.*)")
        if path:
            self._load_archive(path)

    def _pick_folder_mod(self):
        folder = QFileDialog.getExistingDirectory(self, "Sélectionner le dossier du mod FOMOD décompressé")
        if folder:
            self._load_archive(folder)

    def _load_archive(self, file_path: str):
        if self._extract_worker and self._extract_worker.isRunning():
            self._extract_worker.terminate()
            self._extract_worker.wait()

        self._extract_worker = ArchiveExtractWorker(file_path)
        self._extract_worker.finished.connect(self._on_archive_extracted)
        self._extract_worker.error.connect(lambda err: QMessageBox.warning(self, "Erreur", err))
        self._extract_worker.start()

    def _on_archive_extracted(self, index: ArchiveIndex, cfg_xml: str, info_xml: str):
        self.archive_index = index
        self.metadata = parse_info_xml(info_xml)
        mod_name, steps, req_files = parse_module_config_xml(cfg_xml)
        if mod_name:
            self.metadata.name = mod_name
        self.title_label.setText(self.metadata.name)
        self.steps = steps
        self.required_files = req_files
        self.current_step_idx = 0
        self.selected_option_ids.clear()
        self.active_flags.clear()
        self._render_current_step()
        self._trigger_background_staging()

    def _open_image_preview_modal(self):
        if self.active_preview_option:
            pix = get_preview_pixmap_for_path(
                self.active_preview_option.image_path,
                self.active_preview_option.name,
                self.active_preview_option.description,
            )
            modal = ImagePreviewModal(pix, self.active_preview_option.name, self)
            modal.exec()

    def cleanup_workers(self):
        if self._extract_worker and self._extract_worker.isRunning():
            self._extract_worker.terminate()
            self._extract_worker.wait()
        if self._staging_worker and self._staging_worker.isRunning():
            self._staging_worker.terminate()
            self._staging_worker.wait()

    def closeEvent(self, event):
        self.cleanup_workers()
        super().closeEvent(event)


# ==============================================================================
# 9. POINT D'ENTRÉE PRINCIPAL
# ==============================================================================

def setup_logging():
    log_level = logging.DEBUG if os.environ.get("DEBUG") else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="[%(asctime)s] [%(levelname)s] [%(name)s]: %(message)s",
        datefmt="%H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def main():
    setup_logging()
    logger.info("Démarrage du Simulateur FOMOD v1.0 (PyQt6)")

    if hasattr(Qt.ApplicationAttribute, "AA_EnableHighDpiScaling"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling, True)
    if hasattr(Qt.ApplicationAttribute, "AA_UseHighDpiPixmaps"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setApplicationName("FOMOD Simulator")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("SkyrimTools")
    app.setStyleSheet(DARK_THEME_QSS)

    window = MainWindow()

    if len(sys.argv) > 1:
        target_path = sys.argv[1]
        if os.path.exists(target_path):
            logger.info(f"Ouverture directe via CLI : {target_path}")
            window._load_archive(target_path)
        else:
            logger.warning(f"Fichier inexistant : {target_path}")

    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
