#!/bin/bash
# -------------------------------------------------------------
# Script de compilation autonome pour macOS (PyInstaller)
# Génère une application native figée (.app) sans dépendance Python
# -------------------------------------------------------------

set -e

cd "$(dirname "$0")" || exit 1

echo "=========================================================="
echo "    Compilation native de FOMOD Simulator (.app)"
echo "=========================================================="

# 1. Vérification des prérequis
if ! command -v python3 &> /dev/null; then
    echo "Erreur: python3 est requis pour la compilation."
    exit 1
fi

# 2. Installation de PyInstaller et dépendances
python3 -m pip install --quiet --upgrade pyinstaller py7zr PyQt6

# 3. Compilation via PyInstaller Spec
pyinstaller --clean --noconfirm FOMOD_Simulator.spec

echo "=========================================================="
echo "✅ Compilation terminée avec succès !"
echo "L'application compilée est disponible dans : dist/FOMOD Simulator.app"
echo "Vous pouvez la déplacer directement dans /Applications ou sur votre Bureau."
echo "=========================================================="
