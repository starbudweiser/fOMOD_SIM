#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "========================================================"
echo "    Lancement du Simulateur FOMOD v1.0 (Linux)"
echo "========================================================"
if ! command -v python3 &> /dev/null; then
    echo "ERREUR : Python 3 n'a pas été détecté sur votre système."
    echo "Installez-le via : sudo apt install python3 python3-pip (Debian/Ubuntu) ou équivalent."
    exit 1
fi
python3 -m pip install -q --upgrade PyQt6 py7zr
if [ -f "fomod_simulator.pyz" ]; then
    python3 fomod_simulator.pyz "$@"
else
    python3 fomod_simulator_standalone.py "$@"
fi
