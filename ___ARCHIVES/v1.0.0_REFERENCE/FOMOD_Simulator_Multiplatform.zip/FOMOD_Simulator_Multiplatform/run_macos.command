#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "========================================================"
echo "    Lancement du Simulateur FOMOD v1.0 (macOS)"
echo "========================================================"
if ! command -v python3 &> /dev/null; then
    echo "ERREUR : Python 3 n'a pas été détecté sur votre Mac."
    echo "Téléchargez-le sur https://www.python.org/ ou via : brew install python"
    read -n 1 -s -r -p "Appuyez sur une touche pour quitter..."
    exit 1
fi
python3 -m pip install -q --upgrade PyQt6 py7zr
if [ -f "fomod_simulator.pyz" ]; then
    python3 fomod_simulator.pyz "$@"
else
    python3 fomod_simulator_standalone.py "$@"
fi
