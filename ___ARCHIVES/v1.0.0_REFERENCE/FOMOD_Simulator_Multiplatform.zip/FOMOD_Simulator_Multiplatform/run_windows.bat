@echo off
title FOMOD Simulator - Skyrim Modding Tool
cd /d "%~dp0"
echo ========================================================
echo    Lancement du Simulateur FOMOD v1.0 (Windows)
echo ========================================================

where python >nul 2>nul
if %errorlevel% neq 0 (
    where py >nul 2>nul
    if %errorlevel% neq 0 (
        echo ERREUR : Python 3 n'a pas ete detecte sur votre systeme.
        echo Telechargez-le sur https://www.python.org/
        pause
        exit /b 1
    ) else (
        set PY_CMD=py
    )
) else (
    set PY_CMD=python
)

echo Verification des dependances (PyQt6, py7zr)...
%PY_CMD% -m pip install -q --upgrade PyQt6 py7zr

echo Demarrage du Simulateur...
if exist fomod_simulator.pyz (
    %PY_CMD% fomod_simulator.pyz %*
) else (
    %PY_CMD% fomod_simulator_standalone.py %*
)
