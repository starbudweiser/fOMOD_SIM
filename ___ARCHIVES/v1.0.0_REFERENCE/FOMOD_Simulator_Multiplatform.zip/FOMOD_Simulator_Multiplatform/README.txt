================================================================================
           SIMULATEUR FOMOD v1.0 - ÉDITION MULTI-PLATEFORME
================================================================================
Cette archive est universelle et fonctionne sous Windows, macOS et Linux.

LANCEMENT RAPIDE :
------------------
- WINDOWS : Double-cliquez sur 'run_windows.bat'
- macOS   : Double-cliquez sur 'run_macos.command'
- LINUX   : Exécutez './run_linux.sh' ou 'python3 fomod_simulator.pyz'

LANCEMENT EN LIGNE DE COMMANDE (TOUT OS) :
------------------------------------------
1. Installer les prérequis :
   pip install -r requirements.txt

2. Lancer l'application compilée :
   python3 fomod_simulator.pyz
   (ou 'python fomod_simulator.pyz' sous Windows)

CONTENU DE L'ARCHIVE :
----------------------
- fomod_simulator.pyz           : Exécutable Python autonome compressé (ZipApp PEP 441)
- fomod_simulator_standalone.py : Script Python autonome tout-en-un
- run_windows.bat               : Lanceur automatisé pour Windows
- run_macos.command             : Lanceur automatisé pour macOS
- run_linux.sh                  : Lanceur automatisé pour Linux
- requirements.txt              : Liste des dépendances (PyQt6, py7zr)
- assets/                       : Icônes et logos de l'application
================================================================================
